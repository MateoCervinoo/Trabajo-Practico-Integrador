package ar.edu.utn.frc.notificacionesAgencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotificacionesAgenciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
