package ar.edu.utn.frc.notificacionesAgencia.servicies.interfaces;

import ar.edu.utn.frc.notificacionesAgencia.models.NotificacionOferta;

public interface NotificacionOfertaService extends Service<NotificacionOferta, Integer> {
}
