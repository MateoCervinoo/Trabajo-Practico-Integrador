package ar.edu.utn.frc.notificacionesAgencia.servicies;

import ar.edu.utn.frc.notificacionesAgencia.servicies.interfaces.Service;

public abstract class ServiceImpl <T, K> implements Service<T, K> {
}
