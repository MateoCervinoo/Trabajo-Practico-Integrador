package ar.edu.utn.frc.notificacionesAgencia.servicies.interfaces;

import ar.edu.utn.frc.notificacionesAgencia.models.NotificacionAlerta;

public interface NotificacionAlertaService extends Service<NotificacionAlerta, Integer> {
}
