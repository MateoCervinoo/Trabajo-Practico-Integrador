package ar.edu.utn.frc.pruebaAgencia.servicies.interfaces;

import ar.edu.utn.frc.pruebaAgencia.models.Prueba;

public interface PruebaService extends Service<Prueba, Integer> {
}
