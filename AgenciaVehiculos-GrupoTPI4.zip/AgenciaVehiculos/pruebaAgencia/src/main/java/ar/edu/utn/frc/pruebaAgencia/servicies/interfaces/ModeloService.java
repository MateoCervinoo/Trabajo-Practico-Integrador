package ar.edu.utn.frc.pruebaAgencia.servicies.interfaces;

import ar.edu.utn.frc.pruebaAgencia.models.Modelo;

public interface ModeloService extends Service<Modelo, Integer> {
}
