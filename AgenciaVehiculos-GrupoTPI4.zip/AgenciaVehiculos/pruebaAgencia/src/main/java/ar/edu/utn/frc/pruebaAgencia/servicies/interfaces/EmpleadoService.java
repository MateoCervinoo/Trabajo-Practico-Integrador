package ar.edu.utn.frc.pruebaAgencia.servicies.interfaces;

import ar.edu.utn.frc.pruebaAgencia.models.Empleado;

public interface EmpleadoService extends Service<Empleado, Integer> {
}
