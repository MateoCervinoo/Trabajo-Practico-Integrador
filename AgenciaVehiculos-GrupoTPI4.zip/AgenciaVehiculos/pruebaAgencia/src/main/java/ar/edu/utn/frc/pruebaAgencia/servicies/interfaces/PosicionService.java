package ar.edu.utn.frc.pruebaAgencia.servicies.interfaces;

import ar.edu.utn.frc.pruebaAgencia.models.Posicion;

public interface PosicionService extends Service<Posicion, Integer> {
}
