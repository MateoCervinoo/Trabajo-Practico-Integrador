package ar.edu.utn.frc.pruebaAgencia.servicies;

import ar.edu.utn.frc.pruebaAgencia.servicies.interfaces.Service;

public abstract class ServiceImpl<T, K> implements Service<T, K> {
}
