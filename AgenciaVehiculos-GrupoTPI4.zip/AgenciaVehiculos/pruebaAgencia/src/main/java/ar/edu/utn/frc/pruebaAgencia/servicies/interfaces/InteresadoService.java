package ar.edu.utn.frc.pruebaAgencia.servicies.interfaces;

import ar.edu.utn.frc.pruebaAgencia.models.Interesado;

public interface InteresadoService extends Service<Interesado, Integer> {
}
