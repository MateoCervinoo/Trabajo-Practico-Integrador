package ar.edu.utn.frc.pruebaAgencia.servicies.interfaces;

import ar.edu.utn.frc.pruebaAgencia.models.Vehiculo;

public interface VehiculoService extends Service<Vehiculo, Integer> {
}
