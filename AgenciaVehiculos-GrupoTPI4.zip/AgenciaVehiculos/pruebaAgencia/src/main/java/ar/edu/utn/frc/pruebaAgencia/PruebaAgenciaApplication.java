package ar.edu.utn.frc.pruebaAgencia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaAgenciaApplication {

	public static void main(String[] args) {

		SpringApplication.run(PruebaAgenciaApplication.class, args);
	}

}
