package ar.edu.utn.frc.pruebaAgencia.servicies.interfaces;

import ar.edu.utn.frc.pruebaAgencia.models.Incidente;

public interface IncidenteService extends Service<Incidente, Integer>{
}
