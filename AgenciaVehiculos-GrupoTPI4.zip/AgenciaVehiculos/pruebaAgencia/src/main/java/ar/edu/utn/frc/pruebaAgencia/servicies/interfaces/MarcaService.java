package ar.edu.utn.frc.pruebaAgencia.servicies.interfaces;

import ar.edu.utn.frc.pruebaAgencia.models.Marca;

public interface MarcaService extends Service<Marca, Integer> {
}
